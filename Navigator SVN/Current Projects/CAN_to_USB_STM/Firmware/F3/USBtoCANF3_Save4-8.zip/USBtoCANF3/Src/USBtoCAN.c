/*
 * USBtoCAN.c
 *
 *  Created on: Sep 26, 2018
 *      Author: rosem
 */

#include <USBtoCAN.h>

USBtoCAN_t USBtoCAN;

extern UART_HandleTypeDef huart3;
extern CAN_HandleTypeDef hcan;
extern CAN_TxHeaderTypeDef TxHeader;
extern CAN_RxHeaderTypeDef RxHeader;
extern uint8_t TxData[8];
extern uint8_t RxData[8];
extern uint32_t TxMailbox;
extern bool canReceived;
uint8_t startFlagIndex;
uint8_t endFlagIndex;
uint8_t lastID = 0;
bool startFound;
bool endFound;
volatile uint64_t checksumCheck;
volatile uint64_t checksum;
volatile uint8_t UartRecBuffer[BUFFER_SIZE];

/*Test Buffers*/
uint8_t moboBuffer[DEFAULT_DATA_LENGTH];
uint8_t sensorsBuffer[DEFAULT_DATA_LENGTH];

void rotateByOne(uint8_t arr[]) {
	uint8_t i, first;

	/* Store first element of array */
	first = arr[0];

	for (i = 0; i < BUFFER_SIZE - 1; i++) {
		/* Move each array element to its left */
		arr[i] = arr[i + 1];
	}

	/* Copies the first element of array to last */
	arr[BUFFER_SIZE - 1] = first;
}

void InitUSBtoCAN() {
	USBtoCAN.UsbSend = &USBsend;
	USBtoCAN.UsbReceive = &USBreceive;
	USBtoCAN.CanSend = &CANsend;
	USBtoCAN.CanReceive = &CANreceive;
	USBtoCAN.CanFilterId
	USBtoCAN.DataLength = 0;
}

void USBtoCAN_RUN() {
	//cin << endl << "/***************Waiting for start flag....***************/" << endl;
	USBtoCAN.UsbReceive(BUFFER_SIZE);	//receive all the usb at once
	startFlagIndex = 0;
	endFlagIndex = 0;
	startFound = false;
	endFound = false;

	for (uint8_t i = 0; ((i < BUFFER_SIZE) && (!(startFound && endFound)));
			i++) {
		if (USBtoCAN.usbData[i] == STARTFLAG) {
			startFound = true;
		}
		if (USBtoCAN.usbData[i] == ENDFLAG) {
			endFound = true;
		}
	}

	if ((startFound && endFound)) {
		DecodeHeader();	//decode the header and check if a valid message
	}

	if (USBtoCAN.R_nT == RECEIVE) {
		RecCanDataFromP1();
		if (canReceived) {
			SendCanDataToP0_USB();
			canReceived = 0;
		}
		USBtoCAN.R_nT = 0;
	} else if (USBtoCAN.R_nT == TRANSMIT) {
		SendUsbDataToP1_CAN();
		USBtoCAN.R_nT = 0;
	}
}

void DecodeHeader() {
	USBtoCAN.CanFilterId = USBtoCAN.usbData[2];
	uint8_t HeaderControlByte = USBtoCAN.usbData[1];
	USBtoCAN.DataLength = ((0x07) & HeaderControlByte) + 1;
	USBtoCAN.checksum16 = ((0x78) & HeaderControlByte) >> 3;
	USBtoCAN.usbData[1] = ~(0x78) & USBtoCAN.usbData[1];

	if (HeaderControlByte & BIT7) {
		USBtoCAN.R_nT = RECEIVE;
	} else {
		USBtoCAN.R_nT = TRANSMIT;
	}

	checksumCheck = 0;
	if (USBtoCAN.R_nT == TRANSMIT) {
		for (int i = 0; i < USBtoCAN.DataLength + 4; i++) {
			checksumCheck += USBtoCAN.usbData[i];
			asm(" nop");
		}
	} else {
		for (int i = 0; i < 4; i++) {
			checksumCheck += USBtoCAN.usbData[i];
			asm(" nop");
		}
	}
	checksumCheck = checksumCheck % 16;
	if (checksumCheck == USBtoCAN.checksum16) {
		if (USBtoCAN.DataLength > 0) {
			if ((USBtoCAN.R_nT == TRANSMIT)) {
				if ((USBtoCAN.usbData[USBtoCAN.DataLength + 3]) != ENDFLAG) {
					USBtoCAN.R_nT = 0;
				} else {
					TxHeader.StdId = USBtoCAN.CanFilterId;	//changing send ID
					canSetup(lastID, USBtoCAN.DataLength);
				}
			} else {
				if (USBtoCAN.usbData[3] != ENDFLAG) {
					USBtoCAN.R_nT = 0;
				} else {
					if (lastID != USBtoCAN.CanFilterId) {
						canSetup(USBtoCAN.CanFilterId, USBtoCAN.DataLength);
						lastID = USBtoCAN.CanFilterId;
						canReceived = 0;
					}
					asm(" nop");
				}
			}
		}
	} else {
		memset(USBtoCAN.usbData, 0, sizeof(USBtoCAN.usbData));
	}
}

void SendUsbDataToP1_CAN() {
	for (int i = 0; i < USBtoCAN.DataLength; i++) {
		USBtoCAN.canData[i] = USBtoCAN.usbData[i + 3];
	}
	CANsend();
	memset(USBtoCAN.usbData, 0, sizeof(USBtoCAN.usbData));
}

void RecCanDataFromP1() {
	CANreceive();	//USBtoCAN.Data <- Can Receive Buffer
}

void SendCanDataToP0_USB() {
	checksum = 0;
	USBtoCAN.canData[0] = STARTFLAG;
	USBtoCAN.canData[USBtoCAN.DataLength + 2] = ENDFLAG;
	for (int i = 0; i < USBtoCAN.DataLength + 3; i++) {
		if (i != USBtoCAN.DataLength + 1) {
			checksum += USBtoCAN.canData[i];
		}
	}
	checksum = checksum % 16;
	USBtoCAN.canData[USBtoCAN.DataLength + 1] = checksum;
	USBtoCAN.UsbSend(USBtoCAN.DataLength + 3);
	memset(USBtoCAN.usbData, 0, sizeof(USBtoCAN.usbData));
}

void USBsend(uint8_t size) {
	HAL_UART_Transmit_IT(&huart3, USBtoCAN.canData, size);
}

void USBreceive(uint8_t size) {
	HAL_UART_Receive_IT(&huart3, UartRecBuffer, size);
	asm(" nop");

}

void CANsend() {
	HAL_CAN_AddTxMessage(&hcan, &TxHeader, USBtoCAN.canData, &TxMailbox);
}

void CANreceive() {
	for (int i = 1; i < USBtoCAN.DataLength + 1; i++) {
		USBtoCAN.canData[i] = RxData[i - 1];
	}
	asm(" nop");
}

/****************************************************************************************/

